# Database Schema

## TODO 
- [ ] Explain Database Structure

![Database Schema](schema.png?raw=true "Database Schema")



